<?php
    class EmploymentStat{
        // declare 7 properties - id : Integer, year : Integer, 
        // university: String, school : String, degree : String, 
        // employment_rate : Float, avgSalary: Integer
       

        // add code for constructor to initialize the properties of Employment class
     

        // add getter methods for returning the properties of Employment class
       
    }
?>