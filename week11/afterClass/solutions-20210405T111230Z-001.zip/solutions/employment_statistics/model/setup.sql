drop database if exists week11extras;

create database week11extras;
use week11extras;