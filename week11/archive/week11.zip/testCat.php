<?php

require_once 'Cat.php';

$somecat = new Cat('Bryan Adams', 12, 'M', 'P');
$anothercat = new Cat('Christina Aguilera', 3, 'M', 'A');

echo $somecat;

echo '<br>';

echo $anothercat;

?>