<?php

$inventory_array = [
    "East" => [
        "owner" => "Kim Jong Un",
        "items" => [
            'A123' => [
                'description' => "Supreme Shampoo",
                'price' => 5.75,
                'quantity' => 12
            ],
            'B456' => [
                'description' => "Supreme Toothbrush",
                'price' => 3.50,
                'quantity' => 5
            ]
        ]
    ],
    "West" => [
        "owner" => "Kim Yo Jong",
        "items" =>[
            'C789' => [
                'description' => "Supreme Pencil",
                'price' => 1.25,
                'quantity' => 7
            ],
            'D987' => [
                'description' => "Supreme Coffee",
                'price' => 4.75,
                'quantity' => 30
            ],
            'E654' => [
                'description' => "Supreme Beer",
                'price' => 3.75,
                'quantity' => 100
            ]
        ]
    ]
];

?>