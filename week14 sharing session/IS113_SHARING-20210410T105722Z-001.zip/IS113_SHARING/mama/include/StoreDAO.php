<?php

require_once 'Store.php';
require_once 'Item.php';

class StoreDAO {

    private $stores;

    public function __construct() {
        // Pre-populate $stores (Indexed Array)
        $store1 = new Store('East', 'Kim Jong Un');
        $store1->addItem(new Item('A123', "Supreme Shampoo", 5.75, 12));
        $store1->addItem(new Item('B456', "Supreme Toothbrush", 3.50, 5));

        $store2 = new Store('West', 'Kim Yo Jong');
        $store2->addItem(new Item('C789', "Supreme Pencil", 1.25, 7));
        $store2->addItem(new Item('D987', "Supreme Coffee", 4.75, 30));
        $store2->addItem(new Item('E654', "Supreme Beer", 3.75, 100));

        $this->stores = [
            $store1,
            $store2
        ];
    }

    public function getAllStores() {
        // return an IndexedArray of Store objects
        return $this->stores;
    }

    public function getStore($store_name) {

        // return a Store object
    }

    public function getStoreItems($store_name) {

        // return an IndexedArray of Item objects
    }

    public function getItemsByMinQuantity($min_quantity) {

        // return an IndexedArray of Item objects
    }

    public function getItemsByMaxPrice($max_price) {

        // return an IndexedArray of Item objects
    }
}

?>