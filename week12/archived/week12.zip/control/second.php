<html>
<body>

    <h1>second.php</h1>

</body>
</html>