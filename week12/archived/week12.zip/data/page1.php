<html>
<body>

<h1>page1.php</h1>

<form action='page2.php' method='POST'>

    Name: <input type='text' name='name'>

    <?php
        // YOUR CODE GOES HERE
    ?>

    <input type='submit' value='Next'>

</form>

</body>
</html>