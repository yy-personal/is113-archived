<?php

// Form Processing
// Retrieve 'name' & 'age'

// YOUR CODE GOES HERE

?>
<html>
<body>

<h1>page2.php</h1>

<?php
    // YOUR CODE GOES HERE
?>

</body>
</html>