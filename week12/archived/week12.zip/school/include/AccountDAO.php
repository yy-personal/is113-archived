<?php

require_once 'ConnectionManager.php';

class AccountDAO {

    /*
    This method authenticates given username/password
    against the 'account' database table.

    INPUT
        $username (String)
        $password (String)

    OUTPUT
        Return:
            Boolean True (if username/password combo is found in account)
            Boolean False (otherwise)
    */
    public function authenticate($username, $password) {

        // YOUR CODE GOES HERE
        
    }
    
}

?>