<?php

require_once 'ConnectionManager.php';
require_once 'Grade.php';

class GradeDAO {

    /*
    For the given user ($username), this method retrieves all of his/her grades
    from the 'grade' database table.

    INPUT
        $username (String)

    OUTPUT
        Return:
            An Indexed Array of Grade objects
    */
    public function getGrades($username) {

        // YOUR CODE GOES HERE
    }
    
}

?>