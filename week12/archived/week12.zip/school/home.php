<?php

// YOUR CODE GOES HERE

$username = 'somebody';

?>
<html>
<head>
    <title>Home</title>
</head>
<body>

You are logged in as <b><?= $username ?></b> | <a href='logout.php'>Log Out</a>

<hr>

Super confidential data here!!!

</body>
</html>