<html>
<body>

<h1>response.php</h1>

<?php

// YOUR CODE GOES HERE

?>

</body>
</html>