<html>
<body>

<h1>good.php</h1>

<?php

// YOUR CODE GOES HERE

?>

</body>
</html>