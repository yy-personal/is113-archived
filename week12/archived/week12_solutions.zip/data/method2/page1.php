<html>
<body>

    <h1>page1.php</h1>

    <a href='page2.php?name=Bob&age=25'>View Details</a>

</body>
</html>