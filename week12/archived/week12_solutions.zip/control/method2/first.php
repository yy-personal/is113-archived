<html>
<body>

    <h1>first.php</h1>

    <a href='second.php'>Go to second.php</a>

</body>
</html>