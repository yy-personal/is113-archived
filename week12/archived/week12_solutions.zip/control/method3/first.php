<?php

    // Redirect to second.php
    header("Location: second.php");

    exit;

?>