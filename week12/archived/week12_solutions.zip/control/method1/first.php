<html>
<body>

    <h1>first.php</h1>

    <form action='second.php'>

        <input type='submit'>

    </form>

</body>
</html>