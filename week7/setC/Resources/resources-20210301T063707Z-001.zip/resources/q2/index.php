<?php

// Do NOT edit: start
$horoscopeDict = [
   'ARIES' => 'NORMALx2, GOODx2, BADx2, NORMALx3, BAD',
   'TAURUS' => 'GOODx3, NORMALx3, BADx3, NORMAL',
   'GEMINI' => 'NORMALx4, GOOD, BAD, NORMAL, NORMALx2, GOOD',
   'CANCER' => 'BADx2, NORMAL, GOOD, BAD, NORMALx3, BADx2, GOOD',
   'LEO' => 'NORMALx4, GOOD, NORMALx3, GOOD',
   'VIRGO' => 'GOOD, BADx3, NORMAL, BAD, GOOD, BADx4, NORMAL',
   'LIBRA' => 'NORMALx2, GOOD',
   'SCORPIO' => 'NORMALx5, BADx4, NORMAL',
   'SAGITTARIUS' => 'GOODx3, BADx2, NORMAL, GOOD, NORMAL, BAD',
   'CAPRICON' => 'BAD, GOOD, NORMAL',
   'AQUARIUS' => 'NORMAL',
   'PISCES' => 'GOODx6, NORMAL',
];

// The following line "import" the functions declared in the file functions.php
require_once 'functions.php';

// Do NOT edit: end

// process form
// YOUR CODE GOES HERE

?>
<html>
<body>

   Horoscope
   
   Unknown horoscope

</body>
</html>