<?php
// Do NOT change: start
$gender_list = [
   'm' => 'Male',
   'f' => 'Female',
];

$pet_list = [ "cat", "dog", "fish", "other" ];

$fruit_list = [ 'apple', 'orange', 'pear'];
// Do NOT change: end

?>

<html>
<head>
   <style>
      td {
         padding: 5px;
      }
   </style>
</head>
<body>
   
               
</body>
</html>