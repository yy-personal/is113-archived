<?php

// Task 8
// BusyPerson class does NOT know what Pet looks like...
// BusyPerson.php needs to reference Pet class definition
// Which file should BusyPerson.php reference?


// Task 9
// Complete the BusyPerson class definition below

class BusyPerson {

    // Properties (attributes)
    //   name --> String
    //   gender --> String
    //   pets --> Indexed Array (of one or more Pet objects)


    // To make a new BusyPerson object
    // We need this SPECIAL method...
    // HINT: It's used to "construct" a new BusyPerson object


    // Getter method for name


    // Getter method for gender


    // Getter method for pets


    // Every BusyPerson object should be able to greet and say "Hello World! I have X pets"
    // where X is the number of pets (if any) the current BusyPerson object owns
    
}

?>