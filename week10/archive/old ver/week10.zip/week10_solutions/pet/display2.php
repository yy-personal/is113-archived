<?php

// display2.php does NOT have data
// It focuses on DISPLAY-ing data.
// Data come from 'data2.php'
// Task 2
// How do we refer to $petsArr (Indexed Array) from data2.php?
require_once 'data2.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Display Pets (Version 2)</title>
</head>

<body>

    <h2>/is113/week10/pet/display2.php</h2>
    <hr>

    <table border='1'>
        <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Gender</th>
            <th>Age</th>
        </tr>

    <?php
        // Task 3
        // Your Code Goes Here
        // Display each pet's details
        // REFER to $petsArr (from data2.php)
        // HINT: Don't code from scratch! You can re-use your code from display1.php
        foreach($petsArr as $pet) {
            echo "
            <tr>
                <td>{$pet['name']}</td>
                <td>{$pet['type']}</td>
                <td>{$pet['gender']}</td>
                <td>{$pet['age']}</td>
            </tr>
            ";
        }
        
    ?>

    </table>

</body>

</html>