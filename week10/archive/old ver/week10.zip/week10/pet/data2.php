<?php

// Indexed Array of 3 Associative Arrays
// Each inner Associative Array is one pet
$petsArr = [
    [
        'name'   => 'Okja',
        'type'   => 'Super Pig',
        'gender' => 'Female',
        'age'    => 3
    ],
    [
        'name'   => 'King Kong',
        'type'   => 'Gorilla',
        'gender' => 'Male',
        'age'    => 5
    ],
    [
        'name'   => 'Bailey',
        'type'   => 'Beluga Whale',
        'gender' => 'Male',
        'age'    => 7
    ]
];

?>