<?php
// ?
?>
<html>
<body>

    <ul>
    <?php
        // YOUR CODE GOES HERE
        // Display Car objects
    ?>
    </ul>

</body>
</html>