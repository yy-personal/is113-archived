<?php

// Write Car class definition

?>