<?php

// Make new Car objects

$cars = [ ??? ];

/*

// We USED TO use Associative Array...
// to represent and store "things" (e.g. objects).
$cars = [
            [   "year"   => 2008,
                "make"   => 'Honda',
                "model"  => 'Fit',
                "rating" => 7 ],

            [   "year"   => 2016,
                "make"   => 'Hyundai',
                "model"  => 'Sonata',
                "rating" => 6 ],

            [   "year"   => 2000,
                "make"   => 'Toyota',
                "model"  => 'Corolla',
                "rating" => 6 ]
];
*/

?>