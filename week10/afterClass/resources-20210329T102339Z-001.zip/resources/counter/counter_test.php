<?php
    # Enter code here
    
    $c1 = null;
    echo "Before increment - First counter value: <br/>";
    
    
    echo "After incrementing 2 times - First counter value: <br/>";
 
    $c2 = null;
    echo "Before decrement - Second counter value: <br/>";
    
    
    echo "After decrementing 2 times - Second counter value: <br/>";
 
?>