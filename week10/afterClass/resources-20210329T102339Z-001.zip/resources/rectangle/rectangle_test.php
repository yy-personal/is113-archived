<?php
    # Complete code here
    $r1 = null;
    $r2 = null;
    echo 'Rectangle $r1: ' . "<br/>";
    echo 'Rectangle $r2: ' . "<br/>";
    echo "<br/>";
    echo 'The area of $r1 is ' . ' sq cm <br/>';
    echo 'The perimeter of $r1 is ' . ' cm <br/>';
    echo 'The area of $r2 is ' . ' sq cm <br/>';
    echo 'The perimeter of $r2 is ' . ' cm <br/>';
    
?>