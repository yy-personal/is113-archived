<?php
    
    $cylinder1 = null;
    $cylinder2 = null;
    
    echo "Cylinder1: <br/>";
    echo " <br/>";
    echo "Volume = " . "  cubic cm<br/><br/>";

    echo "Cylinder2: <br/>";
    echo " <br/>";
    echo "Volume = " . " cubic cm";

?>