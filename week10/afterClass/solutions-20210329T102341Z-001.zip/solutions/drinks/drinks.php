<?php

require_once 'Drink.php';

$drinks = [
    new Drink( 'Cass Beer'  ,  'cass.jpg'  , 11 ),
    new Drink( 'Fruit Wine' ,  'fruit.jpg' , 15 ),
    new Drink( 'Hite Beer'  ,  'hite.jpg'  , 12  ) ,
    new Drink( 'Rice Wine'  ,  'rice.jpg'  , 16 ),
    new Drink( 'Soju'       ,  'soju.jpg'  , 13 )
];

?>