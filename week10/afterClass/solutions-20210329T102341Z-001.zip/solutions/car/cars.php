<?php

require_once 'Car.php';

$car1 = new Car(2008, 'Honda', 'Fit', 7);
$car2 = new Car(2016, 'Hyundai', 'Sonata', 6);
$car3 = new Car(2000, 'Toyota', 'Corolla', 6);

$cars = [ $car1, $car2, $car3 ];

?>