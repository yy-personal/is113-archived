<?php

// Pyongyang's Best Mama Shop
// Current Inventory
// Imagine that the data are pulled from the back-end MySQL Database

// Associative Array
//    Key   : Item ID
//    Value : Associative Array
$itemsArr = [
    'A001' => [
        'description' => "Supreme Shampoo",
        'price' => 5.75,
        'inventory' => 12
    ],
    'B023' => [
        'description' => "Supreme Toothbrush",
        'price' => 3.50,
        'inventory' => 5
    ],
    'C456' => [
        'description' => "Supreme Pencil",
        'price' => 1.25,
        'inventory' => 7
    ]
];

?>
<!DOCTYPE html>
<html>
<head>
    <title>Mama Shop</title>
</head>

<body>

<h1>Pyongyang's Best Mama Shop</h1>

<form action='process.php' method='POST'>

    <font size='5'><b>Items Available</b></font>

    <table border='1'>

            <tr>
                <th>Item ID</th>
                <th>Item Description</th>
            </tr>

        <?php
        // Your Code Goes Here
        // Read from $itemsArr
        // Loop through and display each item's details (Item ID & Item Description)
        ?>
        
    </table>

    <br>

    
    <font size='5'><b>Your Particulars</b></font>
    <br>

    
        <input type="radio" name="residency" value="local"> Local
    

    
        <input type="radio" name="residency" value="foreigner"> Foreigner
    


    <br>
    Your Name:
        <input type='text' name='your_name' value=''>


    <br>
    <br>

    <input type='submit' value='Show Inventory'>

</form>

<hr>
Click <a href="display.php">here</a> to Reset

</body>

</html>