<?php

// If you want to borrow the class definition of Item
// Which file should you import here?
// How do we import from another PHP file?


// Create $myItem with details: 'X123', 'Supreme Coffee', 15.75, 30
// Create $yourItem with details: 'Y456', 'Supreme Knife', 22.50, 20


// Display $myItem's 1) description, 2) price
// HINT: must use Getter methods



// Display $myItem's price and inventory
echo "Before update, myItem price USD: <br>";
echo "Before update, myItem inventory: <br>";



// Update price to 20.99 and inventory to 10
// HINT: must use Setter methods


// (After update) Display $myItem's price and inventory
echo "After update, myItem price USD: <br>";
echo "After update, myItem inventory: <br>";

?>