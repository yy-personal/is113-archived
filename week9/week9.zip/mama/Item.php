<?php

// Item (Class)
// Item.php provides a "template" for all Item objects.

class Item {

    // Properties
    // What do all Item objects have in common?


    // Constructor
    // Special method - invoked when someone does
    // new Item(...)


    // Getter methods
    


    // Setter methods
    

    
    // Public method

}

?>