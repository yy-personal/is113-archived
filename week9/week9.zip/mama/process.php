<?php

// How do we import from another PHP file?

$errors = []; // Will contain error msgs (if any)

// You need to do a series of form validation checks

// 1) User must select at least 1 item (checkbox)
// Error msg: 'You need to select at least 1 item'

// 2) User MUST indicate residency status (radio button)
// Error msg: 'You need to indicate residency status'

// 3) User MUST provide name (text box)
// Error msg: 'You need to input your name'

// 4) If user provided name, it cannot be empty.
// Error msg: 'Your name cannot be empty'


?>
<!DOCTYPE html>
<html>
<head>
    <title>Process</title>
</head>
<body>

<?php
    if( count($errors) > 0 ) {
        // Oh no! Form is incomplete - got errors!
        
        // Your Code Goes Here
        // Display error messages as an ordered list
        
    }
    else {
        // Form IS complete yay!

        // Your Code Goes Here
        // Retrieve form input values into variables
        

        echo "
        <h1>Hello WHOEVER YOU ARE!</h1>";

        echo "
        <h3>Current Inventory for the selected items are:</h3>";

        echo "
        <table border='1'>

            <tr>
                <th>Item ID</th>
                <th>Item Description</th>
                <th>Price (USD)</th>
                <th>Current Inventory</th>
            </tr>
        ";

        // Your Code Goes Here
        // Read from $itemsArr
        // Loop through each item
        //    IF the item is something that the user selected in display.php
        //    THEN display the item's details
        //       Item ID
        //       Item Description
        //       Price
        //       Current Inventory

        echo "
        </table>";



        // Your Code Goes Here
        // Determine the user's Tax Rate
        $tax = "";
        echo "
        <h3>Your tax rate is $tax</h3>
        ";
    }
?>

<hr>
Click <a href="display.php">here</a> to Home

</body>
</html>