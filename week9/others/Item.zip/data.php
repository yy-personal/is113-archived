<?php

// Associative Array
//    Key   : Item ID
//    Value : Associative Array
$itemsArr = [
    'A001' => [
        'description' => "Supreme Shampoo",
        'price' => 5.75,
        'inventory' => 12
    ],
    'B023' => [
        'description' => "Supreme Toothbrush",
        'price' => 3.50,
        'inventory' => 5
    ],
    'C456' => [
        'description' => "Supreme Pencil",
        'price' => 1.25,
        'inventory' => 7
    ]
];


?>