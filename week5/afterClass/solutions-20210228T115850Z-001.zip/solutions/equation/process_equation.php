<!DOCTYPE html>
<html>
    <head>
        <title>Equation</title>
    </head>
    <body>
        
        <?php 
            // Please enter code here
 
            $x = $_POST['x'];
            $y = $_POST['y'];

            $z = $x * $x + $y;

            echo "The value of Z is $z";

            // End of code
        ?>

    </body>
</html>