<!DOCTYPE html>
<html>
    <head>
        <title>Compute Bus Fare in Far Far Away Land</title>
    </head>
    <body>
        <?php 
            $fare = 0.0;

            // Please enter code here





            // End of code

            echo "Fare is $" . $fare;
        ?>
    </body>
</html>