<!DOCTYPE html>
<html>
    <head>
        <title>Equation</title>
    </head>
    <body>
        <?php
        
            // Please enter code here
 


            // End of code
        ?>

    </body>
</html>