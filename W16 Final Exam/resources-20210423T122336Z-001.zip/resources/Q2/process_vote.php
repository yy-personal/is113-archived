<?php
session_start();
$errors = [];
$age = '';
$gender = '';
$candidate_str = '';



?>
