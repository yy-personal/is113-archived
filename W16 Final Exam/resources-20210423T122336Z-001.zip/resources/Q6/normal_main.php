<?php

// DO NOT MODIFY THIS FILE

require_once 'protect.php';

?>
<html>
<body>

<h1>Normal Main</h1>
<h3>Highly Confidential Info!</h3>

</body>
</html>