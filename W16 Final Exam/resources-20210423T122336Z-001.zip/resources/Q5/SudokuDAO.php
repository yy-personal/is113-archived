<?php

class SudokuDAO {

    public function get() {
        return new Sudoku();
    }
}

?>