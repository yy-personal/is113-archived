<?php
// extra.php

echo "Forrest wanna marry {$_SESSION['forrest_gf']}";

?>