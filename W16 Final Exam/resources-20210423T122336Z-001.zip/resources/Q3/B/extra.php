<?php
// extra.php

$_SESSION['forrest_gf'] = 'Jenny';

?>
