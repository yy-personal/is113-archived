<?php
// display.php

require_once 'extra.php';

echo "Forrest wanna marry {$_SESSION['forrest_gf']}"; 

?>