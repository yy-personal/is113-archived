<?php

// extra.php
session_start();

$_SESSION['forrest_gf'] = 'Jenny';

?>