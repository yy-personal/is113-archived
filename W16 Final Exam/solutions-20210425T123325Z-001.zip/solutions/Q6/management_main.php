<?php

require_once 'protect.php';

?>
<html>
<body>

<h1>Management Main</h1>
<h3>Highly Confidential Info!</h3>

</body>
</html>