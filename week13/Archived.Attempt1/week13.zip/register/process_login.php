<?php

if( isset($_POST['username']) && isset($_POST['pass']) ) {

    $username = $_POST['username'];
    $pass = $_POST['pass'];

    if( $username != '' && $pass != '' ) {
        echo "Username: $username <br> Pass: $pass <hr>";

        

    }
    else {
        $error = 'Both fields must be non-empty!';
        $_SESSION['error'] = $error;
        header('Location: login.php');
        return;
    }

}
else {
    $error = 'Unauthorized access. Log in here!';
    $_SESSION['error'] = $error;
    header('Location: login.php');
    return;
}

?>