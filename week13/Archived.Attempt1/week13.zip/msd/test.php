<?php

require_once 'Person.php';
require_once 'Vehicle.php';

$person = new Person('Bobby', 20);
$person->addVehicle( new Vehicle(2010, 111) );
$person->addVehicle( new Vehicle(2019, 222) );

echo $person;

?>